
# LICENSE UNDER DEVELOPMENT

Copying this Miscellenaneous project (from @Seanpm2001)

You are free to copy and distribute my software anywhere, as long as you abide by the rules of the LICENSE (GNU General Public License V3) and follow these 4 rules:

1. Plagiarism - Plagiarism is never allowed for any of my projects. It is my #1 rule. If you are to use this project, you cannot plagiarize it (claim that you made it and that I didn't)

2. Embedding - If you are to embed this projects files or its source code into another project, you must keep this file, the license file, and the README file with credit to Sean Patrick Myrick (@Seanpm2001)
 
3. Ethics - You must use this project for good and not evil. Unethical purposes such as ransomware, programs with anti-virtual machine/anti-emulator source code, and privacy invasive spyware and data collection are not allowed.

4. Credit - Please give credit when using my software. See §Plagiarism

Additionally

<!-- A. NSFW - You can use my software on any project deemed vulgar or repulsive (such as Internet Pornography, Erotica) as long as it isn't illegal usage. !-->

Copyleft (🄯) Seanpm2001 (2021-2021)

File version: 1 (2021, Monday August 23rd at 6:27 pm)

Original file name: COPYING (changed to COPYINGL so that GitHub wouldn't overwrite the GPL3 as the main license, renaming this file is safe)
